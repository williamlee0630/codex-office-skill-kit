# AI 辦公室技能安裝包 1.0.0

此包包含十個完整技能、原創模擬資料與程式測試。完整講義請使用完整學員工具包。
在 Codex 開啟解壓後資料夾，確認 .agents/skills/<技能名稱>/SKILL.md。
Python 3.10 以上：python -m pip install -r requirements.txt。
測試：python -m unittest discover -s tests -v（此包不含講義與公開發行測試）。
所有模擬案例均須核對原始來源；草稿不寄送，未知資訊與待確認事項不補猜。
tools/install_skills.py 預設預覽，--apply 才複製；同名技能拒絕覆寫。
